var a="/assets/avatar.012979bf.png";export{a as _};
