var s="/assets/load.07d88157.svg";export{s as _};
